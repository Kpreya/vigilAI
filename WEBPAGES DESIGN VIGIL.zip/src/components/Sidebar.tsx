import React from 'react';
import { NavLink } from 'react-router-dom';
export function Sidebar() {
  const navItems = [
  {
    path: '/dashboard',
    icon: 'dashboard',
    label: 'Dashboard'
  },
  {
    path: '/dashboard/incidents',
    icon: 'warning',
    label: 'Incidents'
  },
  {
    path: '/dashboard/pull-requests',
    icon: 'call_split',
    label: 'Pull Requests',
    rotateIcon: true
  },
  {
    path: '/dashboard/applications',
    icon: 'grid_view',
    label: 'Applications'
  }];

  const configItems = [
  {
    path: '/dashboard/api-keys',
    icon: 'vpn_key',
    label: 'API Keys'
  },
  {
    path: '/dashboard/settings',
    icon: 'settings',
    label: 'Settings'
  }];

  const NavItem = ({ item }: {item: any;}) =>
  <NavLink
    to={item.path}
    end={item.path === '/dashboard'}
    className={({ isActive }) =>
    `flex items-center space-x-3 px-4 py-3 transition-all duration-150 group ${isActive ? 'bg-white border border-black shadow-brutal-sm text-black font-semibold active:translate-x-[2px] active:translate-y-[2px] active:shadow-none' : 'text-slate-600 hover:text-black hover:bg-white hover:border hover:border-black hover:shadow-brutal-sm'}`
    }>

      <span
      className={`material-symbols-outlined text-xl ${item.rotateIcon ? 'transform rotate-90' : ''} group-hover:scale-110 transition-transform`}>

        {item.icon}
      </span>
      <span>{item.label}</span>
    </NavLink>;

  return (
    <aside className="w-64 bg-sidebar-bg border-r border-black flex flex-col h-full z-20 flex-shrink-0">
      <div className="p-6 border-b border-black flex items-center space-x-3 bg-white">
        <div className="w-10 h-10 bg-black border border-black flex items-center justify-center shadow-brutal-sm">
          <span className="material-symbols-outlined text-white text-2xl">
            visibility
          </span>
        </div>
        <h1 className="font-display font-bold text-2xl tracking-tight text-black">
          VigilAI
        </h1>
      </div>

      <nav className="flex-1 overflow-y-auto py-6 px-4 space-y-2">
        {navItems.map((item) =>
        <NavItem key={item.path} item={item} />
        )}

        <div className="pt-6 pb-2">
          <p className="px-4 text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
            Configuration
          </p>
        </div>

        {configItems.map((item) =>
        <NavItem key={item.path} item={item} />
        )}
      </nav>

      <div className="p-4 border-t border-black bg-white">
        <div className="flex items-center space-x-3">
          <img
            alt="User Avatar"
            className="w-10 h-10 border border-black"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAbP6PojbYgnA1TylzYXzskcUlKbxY3-7LKLWAWvqQPgt3XROrRX8gTMyaipol-cCtwDcgIFaQLrFiU_ENycBdEuwRPwdhGnv-O69LMBVIHAIfozQ97PCchRePNXLc0t_6hbXbNmpr8lfL5tySNM2UoleTL-gmH9loek_zmIFEeI71PKU0SGXEPhxADsgKAdL3U-F314f_xtYcaADMkZcdsKb2smnSZuztcKzmVKMiLlciQ79Jfs-AmE63vhVG_jhtiJhuOsUcJ-Ks" />

          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-black truncate">Dev Ops</p>
            <p className="text-xs text-slate-500 truncate font-mono">
              admin@vigilai.com
            </p>
          </div>
        </div>
      </div>
    </aside>);

}