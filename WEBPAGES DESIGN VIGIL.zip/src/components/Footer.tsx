import React from 'react';
export function Footer() {
  return (
    <footer className="border-t-4 border-black dark:border-gray-600 bg-white dark:bg-gray-900 py-12 px-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-4">
          <img
            src="/vigilai_logo_clean.png"
            alt="VigilAI Logo"
            className="h-12 w-auto border-2 border-black dark:border-gray-600 shadow-brutal-sm dark:shadow-none bg-white" />

          <span className="font-display font-bold text-2xl tracking-tight dark:text-white">
            VigilAI
          </span>
        </div>

        <div className="flex gap-8 font-mono text-sm font-bold uppercase dark:text-gray-300">
          <a
            href="#"
            className="hover:underline hover:text-primary dark:hover:text-white transition-colors">

            Documentation
          </a>
          <a
            href="#"
            className="hover:underline hover:text-primary dark:hover:text-white transition-colors">

            Status
          </a>
          <a
            href="#"
            className="hover:underline hover:text-primary dark:hover:text-white transition-colors">

            Support
          </a>
        </div>

        <div className="text-xs font-mono text-slate-500 dark:text-gray-400">
          © {new Date().getFullYear()} VigilAI Systems. All rights reserved.
        </div>
      </div>
    </footer>);

}