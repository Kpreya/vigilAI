import React from 'react';
interface TextShimmerProps {
  children: React.ReactNode;
  className?: string;
}
export function TextShimmer({ children, className = '' }: TextShimmerProps) {
  return (
    <span
      className={`inline-flex animate-text-shimmer bg-[linear-gradient(110deg,#000,45%,#fff,55%,#000)] bg-[length:250%_100%] bg-clip-text text-transparent ${className}`}>

      {children}
    </span>);

}