import React, { useState } from 'react';
type FilterType = 'all' | 'active' | 'resolved';
interface Assignee {
  initials: string;
  name: string;
  color: string;
}
interface Incident {
  id: number;
  status: 'open' | 'ackd' | 'solved';
  statusLabel: string;
  severity: 'critical' | 'high' | 'minor';
  severityLabel: string;
  name: string;
  service: string;
  region: string;
  time: string;
  assignee: Assignee | null;
}
const incidents: Incident[] = [
{
  id: 1024,
  status: 'open',
  statusLabel: 'Open',
  severity: 'critical',
  severityLabel: 'Critical',
  name: 'API Gateway Latency Spike',
  service: 'api-gateway',
  region: 'us-east-1',
  time: '12 mins ago',
  assignee: {
    initials: 'JD',
    name: 'J. Doe',
    color: 'bg-slate-200'
  }
},
{
  id: 1023,
  status: 'ackd',
  statusLabel: "Ack'd",
  severity: 'high',
  severityLabel: 'High',
  name: 'Database connection pool exhaustion',
  service: 'db-primary',
  region: 'eu-west-2',
  time: '45 mins ago',
  assignee: {
    initials: 'RK',
    name: 'R. King',
    color: 'bg-purple-200'
  }
},
{
  id: 1022,
  status: 'solved',
  statusLabel: 'Solved',
  severity: 'minor',
  severityLabel: 'Minor',
  name: 'Memory leak in worker node',
  service: 'worker-04',
  region: 'us-west-2',
  time: '2 hours ago',
  assignee: null
},
{
  id: 1021,
  status: 'solved',
  statusLabel: 'Solved',
  severity: 'minor',
  severityLabel: 'Minor',
  name: 'Frontend asset 404s',
  service: 'cdn',
  region: 'global',
  time: '5 hours ago',
  assignee: {
    initials: 'AL',
    name: 'A. Lee',
    color: 'bg-blue-200'
  }
}];

export function IncidentsPage() {
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const filteredIncidents = incidents.filter((inc) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'active')
    return inc.status === 'open' || inc.status === 'ackd';
    if (activeFilter === 'resolved') return inc.status === 'solved';
    return true;
  });
  const getStatusStyles = (status: Incident['status']) => {
    switch (status) {
      case 'open':
        return {
          shadow: 'shadow-[2px_2px_0px_0px_#ef4444]',
          dotColor: 'bg-red-500',
          animate: 'animate-pulse'
        };
      case 'ackd':
        return {
          shadow: 'shadow-[2px_2px_0px_0px_#eab308]',
          dotColor: 'bg-yellow-500',
          animate: ''
        };
      case 'solved':
        return {
          shadow: 'shadow-[2px_2px_0px_0px_#22c55e]',
          dotColor: 'bg-green-500',
          animate: ''
        };
    }
  };
  const getSeverityStyles = (severity: Incident['severity']) => {
    switch (severity) {
      case 'critical':
        return 'border-red-600 text-red-600 bg-red-50';
      case 'high':
        return 'border-yellow-600 text-yellow-700 bg-yellow-50';
      case 'minor':
        return 'border-slate-400 text-slate-600 bg-slate-50';
    }
  };
  return (
    <main className="h-full overflow-y-auto paper-grid relative text-black">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-black px-8 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-display font-bold text-black flex items-center gap-2">
            <span className="material-symbols-outlined">folder_open</span>{' '}
            Incidents
          </h2>
          <div className="hidden md:flex space-x-2">
            <span className="px-2 py-1 bg-white border border-black text-xs font-mono shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              Production
            </span>
            <span className="px-2 py-1 bg-white border border-black text-xs font-mono shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              US-East-1
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="relative group flex-1 md:flex-none">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <span className="material-symbols-outlined text-slate-400 group-focus-within:text-black transition-colors">
                search
              </span>
            </span>
            <input
              className="bg-white border border-black text-sm block w-full md:w-64 pl-10 p-2 text-black placeholder-slate-400 focus:ring-0 focus:border-black focus:shadow-brutal-sm transition-all font-mono outline-none"
              placeholder="Filter incidents..."
              type="text" />

          </div>
          <button className="bg-black text-white px-4 py-2 text-sm font-bold font-mono border border-black hover:bg-white hover:text-black hover:shadow-brutal-sm transition-all flex items-center gap-2 whitespace-nowrap">
            <span className="material-symbols-outlined text-sm">add</span>{' '}
            Create
          </button>
        </div>
      </header>

      <div className="p-8 max-w-7xl mx-auto space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                Open Incidents
              </span>
              <span className="material-symbols-outlined text-black">
                bug_report
              </span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-black">
                12
              </span>
              <span className="text-xs text-red-600 font-bold bg-red-100 px-1 border border-red-200">
                +2
              </span>
            </div>
          </div>
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                Ack'd
              </span>
              <span className="material-symbols-outlined text-black">
                person_check
              </span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-black">4</span>
            </div>
          </div>
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                Resolved
              </span>
              <span className="material-symbols-outlined text-black">
                check_circle
              </span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-black">
                156
              </span>
              <span className="text-xs text-green-600 font-bold bg-green-100 px-1 border border-green-200">
                Today
              </span>
            </div>
          </div>
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                MTTR
              </span>
              <span className="material-symbols-outlined text-black">
                timer
              </span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-black">
                14m
              </span>
              <span className="text-xs text-slate-500">avg</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-black pb-4 mb-4">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 text-xs font-mono border border-black transition-all ${activeFilter === 'all' ? 'bg-black text-white shadow-brutal-sm' : 'bg-white text-slate-600 hover:text-black hover:shadow-brutal-sm'}`}>

              All
            </button>
            <button
              onClick={() => setActiveFilter('active')}
              className={`px-3 py-1.5 text-xs font-mono border border-black transition-all ${activeFilter === 'active' ? 'bg-black text-white shadow-brutal-sm' : 'bg-white text-slate-600 hover:text-black hover:shadow-brutal-sm'}`}>

              Active
            </button>
            <button
              onClick={() => setActiveFilter('resolved')}
              className={`px-3 py-1.5 text-xs font-mono border border-black transition-all ${activeFilter === 'resolved' ? 'bg-black text-white shadow-brutal-sm' : 'bg-white text-slate-600 hover:text-black hover:shadow-brutal-sm'}`}>

              Resolved
            </button>
            <div className="h-8 w-px bg-black mx-2 hidden md:block"></div>
            <select className="px-2 py-1.5 bg-white border border-black text-xs font-mono focus:ring-0 cursor-pointer outline-none">
              <option>Severity: All</option>
              <option>Critical</option>
              <option>Major</option>
              <option>Minor</option>
            </select>
            <select className="px-2 py-1.5 bg-white border border-black text-xs font-mono focus:ring-0 cursor-pointer outline-none">
              <option>Owner: Me</option>
              <option>Team Alpha</option>
              <option>Team Beta</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button className="p-1.5 border border-black bg-white hover:bg-gray-50 text-black transition-colors">
              <span className="material-symbols-outlined text-lg">refresh</span>
            </button>
            <button className="p-1.5 border border-black bg-white hover:bg-gray-50 text-black transition-colors">
              <span className="material-symbols-outlined text-lg">
                download
              </span>
            </button>
          </div>
        </div>

        <div className="bg-white border border-black shadow-brutal overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-100 border-b border-black text-xs uppercase font-mono tracking-wider text-slate-600">
                <th className="p-4 border-r border-black w-16 text-center">
                  #
                </th>
                <th className="p-4 border-r border-black w-32">Status</th>
                <th className="p-4 border-r border-black w-32">Severity</th>
                <th className="p-4 border-r border-black">Incident Name</th>
                <th className="p-4 border-r border-black w-48">Time</th>
                <th className="p-4 w-32">Assignee</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black font-mono text-sm">
              {filteredIncidents.map((incident) => {
                const statusStyles = getStatusStyles(incident.status);
                const severityStyles = getSeverityStyles(incident.severity);
                const isSolved = incident.status === 'solved';
                return (
                  <tr
                    key={incident.id}
                    className="group hover:bg-blue-50 transition-colors">

                    <td className="p-4 border-r border-black text-center text-slate-500">
                      {incident.id}
                    </td>
                    <td className="p-4 border-r border-black">
                      <span
                        className={`inline-flex items-center gap-2 px-2 py-1 rounded-full border border-black bg-white text-xs font-bold ${statusStyles.shadow}`}>

                        <span
                          className={`w-2 h-2 rounded-full ${statusStyles.dotColor} ${statusStyles.animate}`}>
                        </span>
                        {incident.statusLabel}
                      </span>
                    </td>
                    <td className="p-4 border-r border-black">
                      <span
                        className={`px-2 py-0.5 border text-xs font-bold uppercase tracking-wider ${severityStyles}`}>

                        {incident.severityLabel}
                      </span>
                    </td>
                    <td className="p-4 border-r border-black">
                      <a
                        className={`font-sans font-bold hover:underline text-base block mb-1 ${isSolved ? 'text-slate-500 line-through decoration-slate-400 hover:text-black' : 'text-black'}`}
                        href="#">

                        {incident.name}
                      </a>
                      <span className="text-slate-500 text-xs">
                        service: {incident.service} • region: {incident.region}
                      </span>
                    </td>
                    <td className="p-4 border-r border-black text-slate-600">
                      {incident.time}
                    </td>
                    <td className="p-4">
                      {incident.assignee ?
                      <div className="flex items-center gap-2">
                          <div
                          className={`w-6 h-6 rounded-full ${incident.assignee.color} border border-black flex items-center justify-center text-[10px] font-bold`}>

                            {incident.assignee.initials}
                          </div>
                          <span className="text-xs">
                            {incident.assignee.name}
                          </span>
                        </div> :

                      <span className="text-xs text-slate-400 italic">
                          Unassigned
                        </span>
                      }
                    </td>
                  </tr>);

              })}
            </tbody>
          </table>
          <div className="p-4 bg-slate-50 border-t border-black flex justify-between items-center">
            <span className="text-xs font-mono text-slate-500">
              Showing {filteredIncidents.length} of 156 incidents
            </span>
            <div className="flex space-x-2">
              <button className="px-3 py-1 bg-white border border-black text-xs font-mono hover:bg-black hover:text-white transition-colors">
                Prev
              </button>
              <button className="px-3 py-1 bg-white border border-black text-xs font-mono hover:bg-black hover:text-white transition-colors">
                Next
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12 border-2 border-dashed border-slate-300 rounded-lg p-12 flex flex-col items-center justify-center text-center relative overflow-hidden bg-slate-50">
          <div
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#000 1px, transparent 1px)',
              backgroundSize: '20px 20px'
            }}>
          </div>
          <svg
            className="w-48 h-48 mb-6 text-slate-800"
            viewBox="0 0 200 200"
            xmlns="http://www.w3.org/2000/svg">

            <line
              stroke="#cbd5e1"
              strokeDasharray="4 4"
              strokeWidth="1"
              x1="0"
              x2="200"
              y1="100"
              y2="100">
            </line>
            <line
              stroke="#cbd5e1"
              strokeDasharray="4 4"
              strokeWidth="1"
              x1="100"
              x2="100"
              y1="0"
              y2="200">
            </line>
            <rect
              fill="white"
              height="80"
              stroke="currentColor"
              strokeWidth="2"
              width="80"
              x="60"
              y="60">
            </rect>
            <rect
              fill="#f1f5f9"
              height="40"
              stroke="currentColor"
              strokeWidth="1"
              width="60"
              x="70"
              y="70">
            </rect>
            <circle cx="85" cy="90" fill="currentColor" r="5"></circle>
            <circle cx="115" cy="90" fill="currentColor" r="5"></circle>
            <line
              stroke="currentColor"
              strokeWidth="2"
              x1="80"
              x2="120"
              y1="120"
              y2="120">
            </line>
            <line
              stroke="currentColor"
              strokeWidth="2"
              x1="100"
              x2="100"
              y1="60"
              y2="40">
            </line>
            <circle
              cx="100"
              cy="35"
              fill="white"
              r="5"
              stroke="currentColor"
              strokeWidth="2">
            </circle>
            <circle
              cx="140"
              cy="140"
              fill="none"
              r="25"
              stroke="currentColor"
              strokeWidth="2">
            </circle>
            <line
              stroke="currentColor"
              strokeLinecap="round"
              strokeWidth="4"
              x1="158"
              x2="175"
              y1="158"
              y2="175">
            </line>
            <line
              stroke="currentColor"
              strokeWidth="1"
              x1="50"
              x2="50"
              y1="60"
              y2="140">
            </line>
            <line
              stroke="currentColor"
              strokeWidth="1"
              x1="45"
              x2="55"
              y1="60"
              y2="60">
            </line>
            <line
              stroke="currentColor"
              strokeWidth="1"
              x1="45"
              x2="55"
              y1="140"
              y2="140">
            </line>
          </svg>
          <h3 className="text-xl font-bold font-display text-black mb-2">
            No more incidents to investigate
          </h3>
          <p className="text-slate-500 font-mono text-sm max-w-md mx-auto mb-6">
            You've cleared the queue! Our little detective bot is taking a
            coffee break. Check back later or adjust your filters.
          </p>
          <button className="bg-white border border-black px-6 py-2 text-sm font-bold font-mono shadow-brutal-sm hover:translate-y-0.5 hover:shadow-none transition-all active:translate-y-1">
            Refresh Data
          </button>
        </div>
      </div>
    </main>);

}