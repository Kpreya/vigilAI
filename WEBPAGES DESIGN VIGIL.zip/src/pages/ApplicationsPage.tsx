import React from 'react';
export function ApplicationsPage() {
  return (
    <main className="h-full overflow-y-auto paper-grid relative text-black">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-black px-8 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-display font-bold text-black flex items-center gap-2">
            <span className="material-symbols-outlined">grid_view</span>{' '}
            Applications
          </h2>
        </div>
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="relative group flex-1 md:flex-none">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <span className="material-symbols-outlined text-slate-400 group-focus-within:text-black transition-colors">
                search
              </span>
            </span>
            <input
              className="bg-white border border-black text-sm block w-full md:w-64 pl-10 p-2 text-black placeholder-slate-400 focus:ring-0 focus:border-black focus:shadow-brutal-sm transition-all font-mono outline-none"
              placeholder="Search apps..."
              type="text" />

          </div>
          <button className="bg-black text-white px-4 py-2 text-sm font-bold font-mono border border-black hover:bg-white hover:text-black hover:shadow-brutal-sm transition-all flex items-center gap-2 whitespace-nowrap">
            <span className="material-symbols-outlined text-sm">add</span> Add
            Application
          </button>
        </div>
      </header>

      <div className="p-8 max-w-7xl mx-auto flex flex-col items-center justify-center min-h-[calc(100vh-120px)]">
        <div className="w-full max-w-2xl bg-white border border-black shadow-brutal p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-5 pointer-events-none paper-grid"></div>
          <div className="mb-8 flex justify-center">
            <div className="relative w-64 h-64 border-2 border-dashed border-slate-300 bg-slate-50 flex items-center justify-center overflow-hidden">
              <div
                className="absolute inset-0 opacity-10 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(#000 1px, transparent 1px)',
                  backgroundSize: '20px 20px'
                }}>
              </div>
              <svg
                className="w-40 h-40 text-slate-800"
                viewBox="0 0 200 200"
                xmlns="http://www.w3.org/2000/svg">

                <line
                  stroke="#cbd5e1"
                  strokeDasharray="4 4"
                  strokeWidth="1"
                  x1="0"
                  x2="200"
                  y1="100"
                  y2="100">
                </line>
                <line
                  stroke="#cbd5e1"
                  strokeDasharray="4 4"
                  strokeWidth="1"
                  x1="100"
                  x2="100"
                  y1="0"
                  y2="200">
                </line>
                <rect
                  fill="white"
                  height="120"
                  stroke="currentColor"
                  strokeWidth="2"
                  width="80"
                  x="60"
                  y="40">
                </rect>
                <rect
                  fill="#f8fafc"
                  height="15"
                  stroke="currentColor"
                  strokeWidth="1"
                  width="70"
                  x="65"
                  y="45">
                </rect>
                <circle cx="75" cy="52.5" fill="currentColor" r="2"></circle>
                <line
                  stroke="currentColor"
                  strokeWidth="1"
                  x1="85"
                  x2="125"
                  y1="52.5"
                  y2="52.5">
                </line>
                <rect
                  fill="#f1f5f9"
                  height="15"
                  stroke="currentColor"
                  strokeWidth="1"
                  width="70"
                  x="65"
                  y="65">
                </rect>
                <circle cx="75" cy="72.5" fill="currentColor" r="2"></circle>
                <line
                  stroke="currentColor"
                  strokeWidth="1"
                  x1="85"
                  x2="115"
                  y1="72.5"
                  y2="72.5">
                </line>
                <rect
                  fill="#f8fafc"
                  height="15"
                  stroke="currentColor"
                  strokeWidth="1"
                  width="70"
                  x="65"
                  y="85">
                </rect>
                <circle cx="75" cy="92.5" fill="currentColor" r="2"></circle>
                <line
                  stroke="currentColor"
                  strokeWidth="1"
                  x1="85"
                  x2="120"
                  y1="92.5"
                  y2="92.5">
                </line>
                <circle
                  cx="100"
                  cy="115"
                  fill="white"
                  r="4"
                  stroke="currentColor"
                  strokeWidth="1.5">
                </circle>
                <line
                  stroke="currentColor"
                  strokeWidth="1"
                  x1="100"
                  x2="100"
                  y1="119"
                  y2="135">
                </line>
                <rect
                  fill="white"
                  height="20"
                  stroke="currentColor"
                  strokeWidth="1"
                  width="70"
                  x="65"
                  y="135">
                </rect>
                <line
                  stroke="currentColor"
                  strokeWidth="1"
                  x1="90"
                  x2="110"
                  y1="145"
                  y2="145">
                </line>
                <line
                  stroke="currentColor"
                  strokeWidth="0.5"
                  x1="50"
                  x2="60"
                  y1="40"
                  y2="40">
                </line>
                <line
                  stroke="currentColor"
                  strokeWidth="0.5"
                  x1="50"
                  x2="60"
                  y1="160"
                  y2="160">
                </line>
                <line
                  stroke="currentColor"
                  strokeWidth="0.5"
                  x1="50"
                  x2="50"
                  y1="40"
                  y2="160">
                </line>
              </svg>
            </div>
          </div>
          <h3 className="text-3xl font-bold font-display text-black mb-3">
            No applications monitored yet
          </h3>
          <p className="text-slate-500 font-mono text-base max-w-md mx-auto mb-10">
            Register your first application to start tracking incidents and
            performance metrics in real-time.
          </p>
          <button className="bg-black text-white px-8 py-4 text-lg font-bold font-mono border-2 border-black shadow-brutal hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all inline-flex items-center gap-3">
            <span className="material-symbols-outlined font-bold">add_box</span>
            CREATE YOUR FIRST APPLICATION
          </button>

          <div className="mt-12 flex flex-col md:flex-row justify-center gap-8 border-t border-black pt-8">
            <div className="text-left">
              <p className="text-xs font-mono font-bold text-slate-400 uppercase mb-1">
                Step 1
              </p>
              <p className="text-sm font-bold">Register App</p>
            </div>
            <div className="text-left">
              <p className="text-xs font-mono font-bold text-slate-400 uppercase mb-1">
                Step 2
              </p>
              <p className="text-sm font-bold">Install SDK</p>
            </div>
            <div className="text-left">
              <p className="text-xs font-mono font-bold text-slate-400 uppercase mb-1">
                Step 3
              </p>
              <p className="text-sm font-bold">Monitor Life</p>
            </div>
          </div>
        </div>
      </div>
    </main>);

}