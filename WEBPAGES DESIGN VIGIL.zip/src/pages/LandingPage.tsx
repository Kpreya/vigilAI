import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { TextShimmer } from '../components/TextShimmer';
import { Footer } from '../components/Footer';
export function LandingPage() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  useEffect(() => {
    // Check local storage or system preference on mount
    const storedPref = localStorage.getItem('theme');
    if (storedPref === 'dark') {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    } else if (storedPref === 'light') {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };
  return (
    <div className="min-h-screen bg-paper-bg dark:bg-gray-950 flex flex-col selection:bg-black selection:text-white dark:selection:bg-white dark:selection:text-black transition-colors duration-200 text-black dark:text-white">
      {/* Navigation */}
      <nav className="border-b-2 border-black dark:border-gray-600 bg-white dark:bg-gray-900 px-8 py-4 flex justify-between items-center sticky top-0 z-50 transition-colors duration-200">
        <div className="flex items-center gap-3">
          <img
            src="/vigilai_logo_clean.png"
            alt="VigilAI Logo"
            className="w-10 h-10 border-2 border-black dark:border-gray-600 bg-white object-contain" />

          <span className="font-display font-bold text-2xl tracking-tight dark:text-white">
            VigilAI
          </span>
        </div>

        {/* Center nav links */}
        <div className="hidden lg:flex items-center gap-8">
          <a
            href="#about"
            className="font-mono font-bold text-sm hover:underline uppercase tracking-wide dark:text-gray-200">

            About
          </a>
          <a
            href="#features"
            className="font-mono font-bold text-sm hover:underline uppercase tracking-wide dark:text-gray-200">

            Features
          </a>
          <a
            href="#"
            className="font-mono font-bold text-sm hover:underline uppercase tracking-wide dark:text-gray-200">

            Integrations
          </a>
          <a
            href="#"
            className="font-mono font-bold text-sm hover:underline uppercase tracking-wide dark:text-gray-200">

            Pricing
          </a>
          <a
            href="#"
            className="font-mono font-bold text-sm hover:underline uppercase tracking-wide dark:text-gray-200">

            Docs
          </a>
        </div>

        {/* Right side buttons */}
        <div className="flex items-center gap-4">
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex items-center justify-center"
            aria-label="Toggle dark mode">

            <span className="material-symbols-outlined dark:text-white">
              {isDarkMode ? 'light_mode' : 'dark_mode'}
            </span>
          </button>
          <a
            href="#"
            className="hidden md:block bg-white dark:bg-gray-800 text-black dark:text-white px-5 py-2.5 font-mono font-bold text-sm border-2 border-black dark:border-gray-600 hover:shadow-brutal-sm dark:hover:shadow-none transition-all uppercase">

            Request Demo
          </a>
          <Link
            to="/dashboard"
            className="bg-black dark:bg-white text-white dark:text-black px-5 py-2.5 font-mono font-bold text-sm border-2 border-black dark:border-white shadow-brutal-sm dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all uppercase">

            Get Started
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative border-b-2 border-dashed border-black dark:border-gray-600 paper-grid dark:bg-gray-950 transition-colors duration-200">
        <div className="flex flex-col lg:flex-row items-center justify-center p-8 lg:p-16 max-w-7xl mx-auto gap-12 w-full min-h-[80vh]">
          <div className="flex-1 space-y-8 z-10 text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-display font-bold leading-tight tracking-tight uppercase dark:text-white">
              <TextShimmer className="text-black dark:text-white">
                Autonomous
              </TextShimmer>
              <br />
              Incident Resolution
              <br />
              For Modern Systems
            </h1>

            <p className="text-lg lg:text-xl font-mono text-slate-600 dark:text-gray-400 max-w-xl leading-relaxed">
              Detect anomalies in minutes. Diagnose root causes with AI.
              Generate and deploy fixes automatically.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Link
                to="/dashboard"
                className="bg-black dark:bg-white text-white dark:text-black px-8 py-4 text-center font-mono font-bold text-lg border-2 border-black dark:border-white shadow-brutal dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all uppercase flex items-center justify-center gap-2">

                Get Started
              </Link>
              <a
                href="#"
                className="bg-white dark:bg-gray-800 text-black dark:text-white px-8 py-4 text-center font-mono font-bold text-lg border-2 border-black dark:border-gray-600 shadow-brutal dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all uppercase">

                View Docs
              </a>
            </div>
          </div>

          <div className="flex-1 w-full max-w-xl lg:max-w-none flex justify-center lg:justify-end">
            <img
              src="/vigilai_logo_polished.png"
              alt="VigilAI - AI-Powered Monitoring"
              className="w-full max-w-xl h-auto object-contain dark:invert dark:opacity-90 transition-all duration-200" />

          </div>
        </div>
      </section>

      {/* About Section */}
      <section
        id="about"
        className="py-24 px-8 border-b-2 border-dashed border-black dark:border-gray-600 paper-grid dark:bg-gray-950 transition-colors duration-200">

        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-center mb-12">
            <div className="flex-1 border-t-2 border-dashed border-black dark:border-gray-600"></div>
            <h2 className="mx-8 text-3xl md:text-4xl font-display font-bold uppercase tracking-tight dark:text-white">
              About
            </h2>
            <div className="flex-1 border-t-2 border-dashed border-black dark:border-gray-600"></div>
          </div>

          <div className="border-2 border-dashed border-black dark:border-gray-600 p-8 md:p-12 bg-white dark:bg-gray-900 transition-colors duration-200">
            <h3 className="font-display font-bold text-xl mb-6 dark:text-white">
              About VigilAI
            </h3>
            <div className="space-y-6 font-mono text-sm leading-relaxed text-black dark:text-gray-300">
              <p>
                VigilAI is an intelligent system monitoring platform designed to
                detect, diagnose, and resolve production issues automatically.
                Instead of relying on slow, manual incident response processes,
                VigilAI continuously monitors systems in real time, identifies
                anomalies within minutes, analyzes the root cause using AI, and
                generates production-ready fixes through automated code
                generation.
              </p>
              <p>
                When an issue occurs, VigilAI instantly creates a GitHub pull
                request with the generated fix, allowing engineers to quickly
                review and deploy the solution. By automating much of the
                incident response workflow, VigilAI significantly reduces
                downtime, accelerates recovery, and helps teams maintain
                reliable, high-performing systems.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Centered Sentinel Image Section */}
      <section className="py-16 px-8 border-b-2 border-dashed border-black dark:border-gray-600 paper-grid dark:bg-gray-950 transition-colors duration-200">
        <div className="max-w-4xl mx-auto flex justify-center">
          <img
            src="/6152192136858766718.jpg"
            alt="VigilAI Sentinel Diagram"
            className="w-full max-w-3xl h-auto object-contain dark:invert dark:opacity-90 transition-all duration-200" />

        </div>
      </section>

      {/* Features Section */}
      <section
        id="features"
        className="py-24 px-8 bg-white dark:bg-gray-900 border-b-2 border-black dark:border-gray-600 transition-colors duration-200">

        <div className="max-w-7xl mx-auto">
          <p className="font-mono text-sm uppercase tracking-widest text-slate-500 dark:text-gray-400 mb-4">
            Platform Capabilities
          </p>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-16 uppercase tracking-tight dark:text-white">
            Everything you need to stay vigilant
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-gray-800 border-2 border-black dark:border-gray-600 p-8 shadow-brutal dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover transition-all">
              <div className="w-12 h-12 bg-black dark:bg-white flex items-center justify-center mb-6">
                <span className="material-symbols-outlined text-white dark:text-black text-2xl">
                  visibility
                </span>
              </div>
              <h3 className="text-xl font-display font-bold mb-3 uppercase dark:text-white">
                Real-Time Monitoring
              </h3>
              <p className="font-mono text-sm text-slate-600 dark:text-gray-300 leading-relaxed">
                24/7 AI-powered anomaly detection across all your services and
                infrastructure.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 border-2 border-black dark:border-gray-600 p-8 shadow-brutal dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover transition-all">
              <div className="w-12 h-12 bg-black dark:bg-white flex items-center justify-center mb-6">
                <span className="material-symbols-outlined text-white dark:text-black text-2xl">
                  build
                </span>
              </div>
              <h3 className="text-xl font-display font-bold mb-3 uppercase dark:text-white">
                Automated Fix Generation
              </h3>
              <p className="font-mono text-sm text-slate-600 dark:text-gray-300 leading-relaxed">
                Auto-generated pull requests with suggested fixes when incidents
                are detected.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 border-2 border-black dark:border-gray-600 p-8 shadow-brutal dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover transition-all">
              <div className="w-12 h-12 bg-black dark:bg-white flex items-center justify-center mb-6">
                <span className="material-symbols-outlined text-white dark:text-black text-2xl">
                  vpn_key
                </span>
              </div>
              <h3 className="text-xl font-display font-bold mb-3 uppercase dark:text-white">
                Secure API Management
              </h3>
              <p className="font-mono text-sm text-slate-600 dark:text-gray-300 leading-relaxed">
                Enterprise-grade API key management with granular access
                controls.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 px-8 paper-grid dark:bg-gray-950 transition-colors duration-200">
        <div className="max-w-7xl mx-auto">
          <p className="font-mono text-sm uppercase tracking-widest text-slate-500 dark:text-gray-400 mb-4">
            Getting Started
          </p>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-16 uppercase tracking-tight dark:text-white">
            How It Works
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-start">
              <div className="w-12 h-12 bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-display text-2xl font-bold mb-6 shadow-brutal-sm dark:shadow-none">
                1
              </div>
              <h3 className="text-xl font-display font-bold mb-3 uppercase dark:text-white">
                Register Your Application
              </h3>
              <p className="font-mono text-sm text-slate-600 dark:text-gray-400 leading-relaxed">
                Set up monitoring for your services in under 2 minutes.
              </p>
            </div>

            <div className="flex flex-col items-start">
              <div className="w-12 h-12 bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-display text-2xl font-bold mb-6 shadow-brutal-sm dark:shadow-none">
                2
              </div>
              <h3 className="text-xl font-display font-bold mb-3 uppercase dark:text-white">
                Install the SDK
              </h3>
              <p className="font-mono text-sm text-slate-600 dark:text-gray-400 leading-relaxed">
                Add our lightweight SDK to your codebase with a single command.
              </p>
            </div>

            <div className="flex flex-col items-start">
              <div className="w-12 h-12 bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-display text-2xl font-bold mb-6 shadow-brutal-sm dark:shadow-none">
                3
              </div>
              <h3 className="text-xl font-display font-bold mb-3 uppercase dark:text-white">
                Monitor & Auto-Fix
              </h3>
              <p className="font-mono text-sm text-slate-600 dark:text-gray-400 leading-relaxed">
                VigilAI detects issues and generates fixes automatically.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-8 bg-black dark:bg-gray-900 border-t-2 border-black dark:border-gray-600 transition-colors duration-200">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-white uppercase tracking-tight">
            Ready to eliminate downtime?
          </h2>
          <p className="font-mono text-lg text-white/70 mb-10 max-w-2xl mx-auto">
            Join teams using VigilAI to achieve 99.99% uptime.
          </p>
          <Link
            to="/dashboard"
            className="inline-block bg-white text-black px-10 py-5 font-mono font-bold text-lg border-2 border-white shadow-brutal dark:shadow-none hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-brutal-hover active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all uppercase">

            Get Started Free
          </Link>
        </div>
      </section>

      <Footer />
    </div>);

}