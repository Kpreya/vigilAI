import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '../components/Sidebar';
export function DashboardLayout() {
  return (
    <div className="flex h-screen overflow-hidden bg-paper-bg selection:bg-black selection:text-white">
      <Sidebar />
      <div className="flex-1 h-full overflow-hidden relative">
        <Outlet />
      </div>
    </div>);

}