import React from 'react';
export function ApiKeysPage() {
  return (
    <main className="h-full overflow-y-auto paper-grid relative text-black">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-black px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-display font-bold text-black flex items-center gap-2">
            <span className="material-symbols-outlined">vpn_key</span> API Keys
          </h2>
        </div>
        <div className="flex items-center space-x-4">
          <button className="bg-black text-white px-6 py-2.5 text-sm font-bold font-mono border border-black hover:bg-white hover:text-black hover:shadow-brutal-sm transition-all flex items-center gap-2">
            GENERATE NEW KEY
          </button>
        </div>
      </header>

      <div className="p-8 max-w-5xl mx-auto space-y-12">
        <div className="bg-white border border-black p-16 shadow-brutal flex flex-col items-center justify-center text-center relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-5 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#000 1px, transparent 1px)',
              backgroundSize: '20px 20px'
            }}>
          </div>
          <div className="relative mb-10">
            <svg
              className="w-64 h-64 text-slate-800"
              viewBox="0 0 200 200"
              xmlns="http://www.w3.org/2000/svg">

              <line
                stroke="#cbd5e1"
                strokeDasharray="4 4"
                strokeWidth="1"
                x1="0"
                x2="200"
                y1="100"
                y2="100">
              </line>
              <line
                stroke="#cbd5e1"
                strokeDasharray="4 4"
                strokeWidth="1"
                x1="100"
                x2="100"
                y1="0"
                y2="200">
              </line>
              <circle
                cx="60"
                cy="100"
                fill="white"
                r="30"
                stroke="currentColor"
                strokeWidth="2">
              </circle>
              <circle
                cx="60"
                cy="100"
                fill="#f1f5f9"
                r="12"
                stroke="currentColor"
                strokeWidth="1">
              </circle>
              <rect
                fill="white"
                height="20"
                stroke="currentColor"
                strokeWidth="2"
                width="80"
                x="90"
                y="90">
              </rect>
              <rect
                fill="white"
                height="15"
                stroke="currentColor"
                strokeWidth="2"
                width="10"
                x="120"
                y="110">
              </rect>
              <rect
                fill="white"
                height="10"
                stroke="currentColor"
                strokeWidth="2"
                width="10"
                x="140"
                y="110">
              </rect>
              <rect
                fill="white"
                height="15"
                stroke="currentColor"
                strokeWidth="2"
                width="10"
                x="160"
                y="110">
              </rect>
              <line
                stroke="currentColor"
                strokeDasharray="2 2"
                strokeWidth="1"
                x1="30"
                x2="30"
                y1="140"
                y2="160">
              </line>
              <line
                stroke="currentColor"
                strokeDasharray="2 2"
                strokeWidth="1"
                x1="170"
                x2="170"
                y1="140"
                y2="160">
              </line>
              <line
                stroke="currentColor"
                strokeWidth="1"
                x1="30"
                x2="170"
                y1="155"
                y2="155">
              </line>
              <text
                fill="currentColor"
                fontFamily="JetBrains Mono"
                fontSize="8"
                x="85"
                y="150">

                64 CHARS
              </text>
            </svg>
          </div>
          <h3 className="text-2xl font-bold font-display text-black mb-4">
            No API keys yet
          </h3>
          <p className="text-slate-500 font-mono text-sm max-w-md mx-auto mb-8">
            Generate an API key to start sending data from your applications to
            VigilAI.
          </p>
          <button className="bg-black text-white px-8 py-3 text-base font-bold font-mono border border-black hover:bg-white hover:text-black hover:shadow-brutal-sm transition-all active:translate-y-1 active:shadow-none">
            GENERATE YOUR FIRST API KEY
          </button>
        </div>

        <div className="bg-white border border-black shadow-brutal-sm overflow-hidden">
          <div className="bg-slate-100 border-b border-black p-4">
            <h4 className="font-display font-bold text-lg flex items-center gap-2">
              <span className="material-symbols-outlined">help</span> How to use
              API Keys
            </h4>
          </div>
          <div className="p-6 font-mono text-sm space-y-4 bg-white">
            <div className="flex gap-4 items-start">
              <span className="bg-black text-white px-2 py-0.5 font-bold">
                01
              </span>
              <p className="text-slate-700">
                Generate an API key for each application you want to monitor.
              </p>
            </div>
            <div className="flex gap-4 items-start">
              <span className="bg-black text-white px-2 py-0.5 font-bold">
                02
              </span>
              <p className="text-slate-700">
                Install the VigilAI SDK in your application.
              </p>
            </div>
            <div className="flex gap-4 items-start">
              <span className="bg-black text-white px-2 py-0.5 font-bold">
                03
              </span>
              <div className="flex-1 space-y-2">
                <p className="text-slate-700">
                  Configure the SDK with your API key:
                </p>
                <div className="bg-slate-50 border border-black p-3 font-mono text-xs text-slate-600 overflow-x-auto">
                  vigilai.init({'{'}
                  <br />
                  &nbsp;&nbsp;apiKey: 'YOUR_SECRET_API_KEY',
                  <br />
                  &nbsp;&nbsp;environment: 'production'
                  <br />
                  {'}'});
                </div>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <span className="bg-black text-white px-2 py-0.5 font-bold">
                04
              </span>
              <p className="text-slate-700">
                Start monitoring errors and performance metrics automatically.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>);

}