import React from 'react';
export function PullRequestsPage() {
  return (
    <main className="h-full overflow-y-auto paper-grid relative text-black">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-black px-8 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-display font-bold text-black flex items-center gap-2">
            <span className="material-symbols-outlined transform rotate-90">
              call_split
            </span>{' '}
            Pull Requests
          </h2>
          <div className="hidden md:flex space-x-2">
            <span className="px-2 py-1 bg-white border border-black text-xs font-mono shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              Auto-Fix
            </span>
            <span className="px-2 py-1 bg-white border border-black text-xs font-mono shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              v2.4.0
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="relative group flex-1 md:flex-none">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <span className="material-symbols-outlined text-slate-400 group-focus-within:text-black transition-colors">
                search
              </span>
            </span>
            <input
              className="bg-white border border-black text-sm block w-full md:w-64 pl-10 p-2 text-black placeholder-slate-400 focus:ring-0 focus:border-black focus:shadow-brutal-sm transition-all font-mono outline-none"
              placeholder="Search PRs..."
              type="text" />

          </div>
          <button className="bg-black text-white px-4 py-2 text-sm font-bold font-mono border border-black hover:bg-white hover:text-black hover:shadow-brutal-sm transition-all flex items-center gap-2 whitespace-nowrap">
            <span className="material-symbols-outlined text-sm">build</span> New
            Fix
          </button>
        </div>
      </header>

      <div className="p-8 max-w-7xl mx-auto space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                Open PRs
              </span>
              <span className="material-symbols-outlined text-black">
                account_tree
              </span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-black">0</span>
              <span className="text-xs text-slate-400 font-mono">active</span>
            </div>
          </div>
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                Merged
              </span>
              <span className="material-symbols-outlined text-black">
                merge
              </span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-black text-terminal-green">
                0
              </span>
              <span className="text-xs text-slate-400 font-mono">
                this week
              </span>
            </div>
          </div>
          <div className="bg-white border border-black p-5 shadow-brutal-sm hover:shadow-brutal-hover transition-all duration-200 cursor-default">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-mono text-xs uppercase font-bold tracking-wider">
                Pending Review
              </span>
              <span className="material-symbols-outlined text-black">rule</span>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-mono font-bold text-terminal-yellow">
                0
              </span>
              <span className="text-xs text-slate-400 font-mono">awaiting</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-black pb-4">
          <div className="flex flex-wrap gap-2">
            <button className="px-3 py-1.5 bg-black text-white text-xs font-mono border border-black shadow-brutal-sm">
              All PRs
            </button>
            <button className="px-3 py-1.5 bg-white text-slate-600 hover:text-black text-xs font-mono border border-black hover:shadow-brutal-sm transition-all">
              My PRs
            </button>
            <button className="px-3 py-1.5 bg-white text-slate-600 hover:text-black text-xs font-mono border border-black hover:shadow-brutal-sm transition-all">
              Archived
            </button>
            <div className="h-8 w-px bg-black mx-2 hidden md:block"></div>
            <select className="px-2 py-1.5 bg-white border border-black text-xs font-mono focus:ring-0 cursor-pointer outline-none">
              <option>Repository: All</option>
              <option>main-api</option>
              <option>frontend-v3</option>
              <option>infra-cdk</option>
            </select>
          </div>
        </div>

        <div className="mt-8 border-2 border-dashed border-slate-300 rounded-lg p-16 flex flex-col items-center justify-center text-center relative overflow-hidden bg-white shadow-brutal-sm">
          <div
            className="absolute inset-0 opacity-[0.03] pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#000 1.5px, transparent 1.5px)',
              backgroundSize: '30px 30px'
            }}>
          </div>
          <div className="relative w-64 h-64 mb-8">
            <svg
              className="w-full h-full text-slate-800"
              viewBox="0 0 200 200"
              xmlns="http://www.w3.org/2000/svg">

              <line
                stroke="#e2e8f0"
                strokeDasharray="8 4"
                strokeWidth="1"
                x1="0"
                x2="200"
                y1="100"
                y2="100">
              </line>
              <line
                stroke="#e2e8f0"
                strokeDasharray="8 4"
                strokeWidth="1"
                x1="100"
                x2="100"
                y1="0"
                y2="200">
              </line>
              <g transform="translate(40, 40) rotate(-45, 60, 60)">
                <rect
                  fill="white"
                  height="80"
                  rx="2"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  width="20"
                  x="50"
                  y="20">
                </rect>
                <path
                  d="M40,20 Q60,0 80,20 L80,45 L40,45 Z"
                  fill="white"
                  stroke="currentColor"
                  strokeWidth="2.5">
                </path>
                <rect
                  fill="#fafafa"
                  height="20"
                  stroke="currentColor"
                  strokeWidth="2"
                  width="16"
                  x="52"
                  y="5">
                </rect>
              </g>
              <circle
                cx="150"
                cy="150"
                fill="none"
                r="25"
                stroke="currentColor"
                strokeDasharray="4 2"
                strokeWidth="2">
              </circle>
              <circle
                cx="150"
                cy="150"
                fill="white"
                r="15"
                stroke="currentColor"
                strokeWidth="2">
              </circle>
              <line
                stroke="currentColor"
                strokeWidth="1"
                x1="30"
                x2="30"
                y1="50"
                y2="150">
              </line>
              <line
                stroke="currentColor"
                strokeWidth="1"
                x1="25"
                x2="35"
                y1="50"
                y2="50">
              </line>
              <line
                stroke="currentColor"
                strokeWidth="1"
                x1="25"
                x2="35"
                y1="150"
                y2="150">
              </line>
              <text
                className="font-mono text-[10px] font-bold"
                transform="rotate(-90, 15, 105)"
                x="15"
                y="105">

                120mm
              </text>
              <g className="font-mono text-[8px] fill-slate-400">
                <text x="110" y="40">
                  REF: FIX_ENGINE_01
                </text>
                <text x="110" y="52">
                  TOLERANCE: +/- 0.05
                </text>
              </g>
            </svg>
          </div>
          <h3 className="text-2xl font-bold font-display text-black mb-3">
            No pull requests yet
          </h3>
          <p className="text-slate-500 font-mono text-sm max-w-md mx-auto mb-8">
            When incidents are detected, VigilAI's automated diagnostic engine
            will generate pull requests with suggested fixes here.
          </p>
          <div className="flex gap-4">
            <button className="bg-black text-white border border-black px-8 py-3 text-sm font-bold font-mono shadow-brutal hover:translate-y-[-2px] hover:shadow-brutal-hover transition-all active:translate-y-0 active:shadow-brutal-sm">
              Configure Auto-Fix
            </button>
            <button className="bg-white border border-black px-8 py-3 text-sm font-bold font-mono shadow-brutal-sm hover:bg-slate-50 transition-all">
              View Docs
            </button>
          </div>
        </div>

        <div className="opacity-30 pointer-events-none select-none mt-12 bg-white border border-black shadow-brutal overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-50 border-b border-black text-xs uppercase font-mono tracking-wider text-slate-600">
                <th className="p-4 border-r border-black w-16 text-center">
                  ID
                </th>
                <th className="p-4 border-r border-black">Pull Request Name</th>
                <th className="p-4 border-r border-black w-32 text-center">
                  Status
                </th>
                <th className="p-4 border-r border-black w-48">
                  Target Branch
                </th>
                <th className="p-4 w-32">Author</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black font-mono text-sm bg-slate-50">
              <tr>
                <td
                  className="p-12 text-center text-slate-400 font-mono italic"
                  colSpan={5}>

                  Empty state: awaiting automated diagnostics...
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>);

}