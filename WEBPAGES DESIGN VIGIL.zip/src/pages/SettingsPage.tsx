import React from 'react';
export function SettingsPage() {
  return (
    <main className="h-full overflow-y-auto paper-grid relative text-black">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-black px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-display font-bold text-black flex items-center gap-2">
            <span className="material-symbols-outlined">settings</span> Settings
          </h2>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-xs font-mono text-slate-500">
            Last synced: 14:02:21
          </div>
        </div>
      </header>

      <div className="p-8 max-w-4xl mx-auto space-y-12">
        <section>
          <h3 className="text-3xl font-display font-bold text-black mb-2">
            Account Settings
          </h3>
          <p className="text-slate-500 font-mono text-sm uppercase tracking-wide">
            Manage your system preferences and user profile.
          </p>
        </section>

        <div className="bg-white border-2 border-black shadow-brutal p-8 space-y-8">
          <div className="border-b-2 border-black pb-4">
            <h4 className="text-xl font-bold font-display uppercase tracking-tight">
              Profile Information
            </h4>
          </div>
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="block text-xs font-mono font-bold text-slate-500 uppercase">
                Username
              </label>
              <input
                className="w-full bg-white border-2 border-black p-3 font-mono text-sm focus:ring-0 focus:border-black focus:shadow-brutal-sm transition-all outline-none"
                placeholder="Enter username"
                type="text"
                defaultValue="Dev Ops" />

            </div>
            <div className="space-y-2">
              <label className="block text-xs font-mono font-bold text-slate-500 uppercase">
                Email Address
              </label>
              <input
                className="w-full bg-slate-50 border-2 border-black p-3 font-mono text-sm text-slate-500 cursor-not-allowed outline-none"
                readOnly
                type="email"
                defaultValue="admin@vigilai.com" />

              <p className="text-[10px] font-mono text-slate-400">
                Email cannot be changed. Contact administrator for updates.
              </p>
            </div>
            <div className="flex justify-end pt-4">
              <button className="bg-black text-white px-8 py-3 text-sm font-bold font-mono border-2 border-black hover:bg-white hover:text-black hover:shadow-brutal transition-all active:translate-x-1 active:translate-y-1 active:shadow-none">
                SAVE CHANGES
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white border-2 border-black shadow-brutal p-8 space-y-8">
          <div className="border-b-2 border-black pb-4 flex justify-between items-center">
            <h4 className="text-xl font-bold font-display uppercase tracking-tight">
              Notification Preferences
            </h4>
            <span className="material-symbols-outlined">
              notifications_active
            </span>
          </div>
          <div className="space-y-6">
            <div className="space-y-4">
              <label className="flex items-center space-x-4 group cursor-pointer">
                <input
                  defaultChecked
                  className="brutal-checkbox"
                  type="checkbox" />

                <span className="font-mono text-sm group-hover:underline">
                  Email notifications for critical incidents
                </span>
              </label>
              <label className="flex items-center space-x-4 group cursor-pointer">
                <input
                  defaultChecked
                  className="brutal-checkbox"
                  type="checkbox" />

                <span className="font-mono text-sm group-hover:underline">
                  Daily summary report (09:00 UTC)
                </span>
              </label>
              <label className="flex items-center space-x-4 group cursor-pointer">
                <input className="brutal-checkbox" type="checkbox" />
                <span className="font-mono text-sm group-hover:underline">
                  Browser desktop notifications
                </span>
              </label>
              <label className="flex items-center space-x-4 group cursor-pointer">
                <input
                  defaultChecked
                  className="brutal-checkbox"
                  type="checkbox" />

                <span className="font-mono text-sm group-hover:underline">
                  Alerts for unassigned open PRs
                </span>
              </label>
            </div>
            <div className="pt-6 border-t border-black border-dashed flex justify-between items-center">
              <p className="text-[10px] font-mono text-slate-400">
                Settings last updated: 2 days ago
              </p>
              <button className="bg-white text-black px-8 py-3 text-sm font-bold font-mono border-2 border-black hover:bg-black hover:text-white hover:shadow-brutal transition-all active:translate-x-1 active:translate-y-1 active:shadow-none">
                UPDATE PREFERENCES
              </button>
            </div>
          </div>
        </div>

        <div className="border-2 border-dashed border-red-500 bg-red-50/50 p-8">
          <div className="flex items-center gap-3 text-red-600 mb-4">
            <span className="material-symbols-outlined">warning</span>
            <h4 className="text-lg font-bold font-display uppercase">
              Danger Zone
            </h4>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="max-w-md">
              <p className="font-mono text-sm text-red-700">
                Disconnect from system and revoke all active sessions. This
                action cannot be undone.
              </p>
            </div>
            <button className="bg-white text-red-600 px-6 py-2 text-xs font-bold font-mono border-2 border-red-600 hover:bg-red-600 hover:text-white transition-all shadow-brutal-sm hover:shadow-none whitespace-nowrap">
              REVOKE ACCESS
            </button>
          </div>
        </div>

        <footer className="text-center py-12">
          <p className="text-[10px] font-mono text-slate-400 tracking-widest uppercase">
            VigilAI System • Version 4.2.0-STABLE
          </p>
        </footer>
      </div>
    </main>);

}